from flask import Flask
from flask import render_template
from data import db_session
from data.jobs import Jobs


app = Flask(__name__)
db_session.global_init("db/mars_explorer.sqlite")
session = db_session.create_session()
jobs = session.query(Jobs).all()
for i in range(len(jobs)):
    jobs[i - 1] = list([jobs[i - 1].job, jobs[i - 1].team_leader, jobs[i - 1].work_size,
                       jobs[i - 1].collaborators, jobs[i - 1].is_finished])


@app.route('/')
def index():
    return render_template('base.html', jobs=jobs)


if __name__ == '__main__':
    app.run(port = 8080, host = '127.0.0.1')
