from flask import Flask
from flask import render_template
from flask_wtf import FlaskForm
from wtforms import PasswordField, SubmitField, StringField
from wtforms.validators import DataRequired
from data import db_session
from data.users import User
from datetime import datetime


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
db_session.global_init("db/mars_explorer.sqlite")


class RegisterForm(FlaskForm):
    email = StringField('Почта', validators = [DataRequired()])
    password = PasswordField('Пароль', validators = [DataRequired()])
    password_again = PasswordField('Повторите пароль', validators = [DataRequired()])
    surname = StringField('Фамилия', validators=[DataRequired()])
    name = StringField('Имя', validators = [DataRequired()])
    age = StringField('Возраст', validators = [DataRequired()])
    position = StringField('Позиция', validators = [DataRequired()])
    speciality = StringField('Специальность', validators = [DataRequired()])
    address = StringField("Адресс")
    submit = SubmitField('Подтвердить')


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        session = db_session.create_session()
        if session.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            surname=form.surname.data,
            email=form.email.data,
            age=form.age.data,
            position=form.position.data,
            speciality=form.speciality.data,
            address=form.address.data,
            modified_date=datetime.now()
        )
        user.set_password(form.password.data)
        session.add(user)
        session.commit()
    return render_template('register.html', title='Регистрация', form=form)


if __name__ == '__main__':
    app.run(port = 8080, host = '127.0.0.1')
